# FaceMaskDetection > 2024-04-17 5:03pm
https://universe.roboflow.com/face-mask-4ehkw/facemaskdetection-b2nbk

Provided by a Roboflow user
License: CC BY 4.0

